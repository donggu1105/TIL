package com.fittv.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FittvAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(FittvAdminApplication.class, args);
	}

}
