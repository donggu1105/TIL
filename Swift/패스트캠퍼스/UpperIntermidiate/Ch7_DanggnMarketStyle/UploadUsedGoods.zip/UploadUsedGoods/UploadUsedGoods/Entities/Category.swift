//
//  Category.swift
//  UploadUsedGoods
//
//  Created by Bo-Young PARK on 2021/09/09.
//

import Foundation

struct Category {
    let id: Int
    let name: String
}
