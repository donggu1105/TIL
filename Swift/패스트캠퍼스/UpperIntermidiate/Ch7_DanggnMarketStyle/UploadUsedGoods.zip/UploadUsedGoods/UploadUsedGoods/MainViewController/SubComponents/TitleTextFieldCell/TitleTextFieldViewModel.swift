//
//  TitleTextFieldViewModel.swift
//  UploadUsedGoods
//
//  Created by Bo-Young PARK on 2021/09/09.
//

import RxCocoa

struct TitleTextFieldViewModel {
    let titleText = PublishRelay<String?>()
}
