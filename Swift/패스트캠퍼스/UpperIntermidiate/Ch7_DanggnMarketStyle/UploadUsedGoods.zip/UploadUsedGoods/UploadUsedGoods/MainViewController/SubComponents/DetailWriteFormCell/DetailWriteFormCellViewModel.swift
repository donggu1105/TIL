//
//  DetailWriteFormCellViewModel.swift
//  UploadUsedGoods
//
//  Created by Bo-Young PARK on 2021/09/09.
//

import RxSwift
import RxCocoa

struct DetailWriteFormCellViewModel {
    let contentValue = PublishRelay<String?>()
}
