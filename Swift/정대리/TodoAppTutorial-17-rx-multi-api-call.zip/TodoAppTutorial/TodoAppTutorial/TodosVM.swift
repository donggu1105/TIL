//
//  TodosVM.swift
//  TodoAppTutorial
//
//  Created by Jeff Jeong on 2022/11/20.
//

import Foundation
import Combine
import RxSwift
import RxCocoa
import RxRelay

class TodosVM: ObservableObject {
    
    var disposeBag = DisposeBag()
    
    init(){
        print(#fileID, #function, #line, "- ")
        
        TodosAPI.deleteSelectedTodosWithObservableMerge(selectedTodoIds: [1294, 783, 1039, 1295, 784])
            .subscribe(onNext: { deletedTodo in
                print("TodosVM - deleteSelectedTodosWithObservable : deletedTodo : \(deletedTodo)")
            }, onError: { err in
                print("TodosVM - deleteSelectedTodosWithObservable : err : \(err)")
            })
            .disposed(by: disposeBag)
        
        
//        TodosAPI.deleteSelectedTodosWithObservable(selectedTodoIds: [1290, 1292, 1293, 782, 1038])
//            .subscribe(onNext: { deletedTodos in
//                print("TodosVM - deleteSelectedTodosWithObservable : deletedTodos : \(deletedTodos)")
//            }, onError: { err in
//                print("TodosVM - deleteSelectedTodosWithObservable : err : \(err)")
//            })
//            .disposed(by: disposeBag)
        
//        TodosAPI.addATodoAndFetchTodosWithObservable(title: "오늘도 빡코딩 - 정대리가 추가함! 111") // [Todo]
//            .observe(on: MainScheduler.instance)
//            .subscribe(onNext: { [weak self] (response : [Todo]) in
//                print("TodosVM - addATodoAndFetchTodosWithObservable : response : \(response)")
//            }).disposed(by: disposeBag)
    }// init
    
    
    
    /// API 에러처리
    /// - Parameter err: API 에러
    fileprivate func handleError(_ err: Error) {
        
        if err is TodosAPI.ApiError {
            let apiError = err as! TodosAPI.ApiError
            
            print("handleError : err : \(apiError.info)")
            
            switch apiError {
            case .noContent:
                print("컨텐츠 없음")
            case .unauthorized:
                print("인증안됨")
            case .decodingError:
                print("디코딩 에러입니당ㅇㅇ")
            default:
                print("default")
            }
        }
        
    }// handleError
    
}
