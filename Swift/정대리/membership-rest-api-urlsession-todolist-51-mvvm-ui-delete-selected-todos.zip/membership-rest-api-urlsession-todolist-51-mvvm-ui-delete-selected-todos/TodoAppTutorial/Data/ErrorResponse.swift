//
//  ErrorResponse.swift
//  TodoAppTutorial
//
//  Created by Jeff Jeong on 2023/01/19.
//

import Foundation


struct ErrorResponse: Decodable {
    let message: String?
}
